"""All models for pmoapp Django application.
"""
from django.db import models


class CurrentReport(models.Model):
    """crisis_ID = models.
    crisis_name = models.CharField(max_length=100)
    crisis_description =
    crisis_dateTime
    updates_curInjuries
    updates_curDeaths
    updates_curThreatLevel
    updates_curRadius
    updates_curSAF
    updates_curCD
    updates_curSCDF
    plan_ID
    plan_description =
    plan_status =
    plan_projRadius
    plan_projCasualtyRate
    plan_projResolutionTime
    plan_SAFRecommended
    plan_CDRecommended
    plan_SCDFRecommended
    plan_SAFMaximum
    plan_CDMaximum
    plan_SCDFMaximum"""

class user(models.Model):
    """
    username =
    password =
    emailAddr =
    user_type = #Enum
    """







