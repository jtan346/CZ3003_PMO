from django.conf.urls import url
from django.contrib import admin
from views import *

urlpatterns = [ #pylint: disable=invalid-name
    url(r'^$', login, name='login'),
    url(r'^authotp$', otp, name='otp'),
    url(r'^home$', home, name='home'),
    url(r'^report/(?P<crisis_id>[0-9]{8})$', report, name='report')
]

""" url(r'^login$', login, name='login'),
    url(r'^authotp$', otp, name='otp'),
    url(r'^home$', home, name='home'),
    url(r'^report$', report, name='report'),
    url(r'^livefeed$', livefeed, name='livefeed'),
    url(r'^history$', history, name='history')"""
    #remove .html from links
    #update the path of the html files
    #for each view, go to pmoapp\urls to create a url, and view.py to create a view.
