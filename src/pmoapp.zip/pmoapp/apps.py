"""Django application configuration for pmoapp.
"""
from django.apps import AppConfig


class pmoappConfig(AppConfig):
    """Application configuration for pmoapp."""
    name = 'pmoapp'
